<OwnershipDatabase.java content>
