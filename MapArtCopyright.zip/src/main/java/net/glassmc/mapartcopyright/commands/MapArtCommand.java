<MapArtCommand.java content>
