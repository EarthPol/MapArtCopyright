<MenuCommand.java content>
