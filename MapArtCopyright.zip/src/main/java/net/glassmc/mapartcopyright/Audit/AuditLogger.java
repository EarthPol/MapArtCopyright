<AuditLogger.java content>
