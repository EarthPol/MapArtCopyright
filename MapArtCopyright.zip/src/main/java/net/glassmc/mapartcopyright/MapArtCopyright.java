<MapArtCopyright.java content>
